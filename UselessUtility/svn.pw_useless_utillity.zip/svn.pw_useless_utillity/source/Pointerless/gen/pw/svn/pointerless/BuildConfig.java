/** Automatically generated file. DO NOT MODIFY */
package pw.svn.pointerless;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}